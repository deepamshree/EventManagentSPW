<script>
        $("li .fa-sort-desc").click(function(){
            $("ul ul").slideToggle();
        });
    </script>
</body>
</html>
