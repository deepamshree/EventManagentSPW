
<?php 

include("dbconnect.php"); 

 

if ($_SERVER["REQUEST_METHOD"] == "POST") { 

    $eventid = $_POST["eventid"]; 

    $stmt = mysqli_prepare($db_connect, "DELETE FROM customer WHERE eventid = ?"); 

    mysqli_stmt_bind_param($stmt, "i", $eventid); 

    mysqli_stmt_execute($stmt); 

    $rowsAffected = mysqli_stmt_affected_rows($stmt); 

    mysqli_stmt_close($stmt); 

 

    if ($rowsAffected > 0) { 

        echo "<script type='text/javascript'> 

            alert('Successfully Deleted!'); 

            window.location = 'delete.php'; 

        </script>"; 

    } else { 

        echo "<script type='text/javascript'> 

            alert('Deletion Failed!'); 

            window.location = 'delete.php'; 

        </script>"; 

    } 

} 

 

mysqli_close($db_connect); 

?> 