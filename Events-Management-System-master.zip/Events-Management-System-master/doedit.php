<?php 

include("dbconnect.php"); 

 

$eventid = mysqli_real_escape_string($db_connect, $_REQUEST['eventid']); 

$name = mysqli_real_escape_string($db_connect, $_REQUEST['name']); 

$email = mysqli_real_escape_string($db_connect, $_REQUEST['email']); 

$phone = mysqli_real_escape_string($db_connect, $_REQUEST['phone']); 

$gender = mysqli_real_escape_string($db_connect, $_REQUEST['gender']); 

 

// Check if the logged-in user has the necessary privileges to edit or update the record 

// Replace with your own logic for user authentication and authorization 

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') { 

    echo "<script type='text/javascript'>alert('You do not have the necessary privileges to perform this action!'); 

 

    window.location = 'edit.php'; 

 

    </script>"; 

    exit(); 

} 

 

// Use prepared statements to prevent SQL injection attacks 

$stmt = mysqli_prepare($db_connect, "UPDATE customer SET name=?, email=?, phone=?, gender=? WHERE eventid=?"); 

mysqli_stmt_bind_param($stmt, "ssssi", $name, $email, $phone, $gender, $eventid); 

$query = mysqli_stmt_execute($stmt); 

 

if(!$query) { 

    echo "<script type='text/javascript'>alert('Error in Submission! Try Again '); 

 

    window.location = 'edit.php'; 

 

    </script>"; 

} else { 

    echo "<script type='text/javascript'>alert('Successfully Submitted! '); 

 

    window.location = 'edit.php'; 

 

    </script>"; 

} 

 

mysqli_stmt_close($stmt); 

mysqli_close($db_connect); 

?> 