<?php include('header.php'); ?>

<HTML>
<BODY bgcolor=#d6eaf8>
<style>


</style>



  
<div class="card-deck">
<div class="card" >
  <img src="simple1.jpg" alt="Avatar" style="width:100%">
  <div class="container">
    <center><h4><b>Simple Ballon Decoration</b></h4> 
	<center><h4 style="color:darkblue;"><b>Decoration id: 1</b></h4>
    <p>€500</p> 
	  
	   
    
   </div>
</div>



<div class="card" position:relative>
  <img src="ballons.jpg" alt="Avatar"  style=" width:100% ">
  <div class="container">
    <center><h4><b>Helium Ballon Decoration</b></h4>
<center><h4 style="color:darkblue;"><b>Decoration id: 2</b></h4>	
    <p>€500</p> 
    
    
  </div>
</div>


<div class="card">
  <img src="baloon arch.jpg" alt="Avatar" style="width:100%">
  <div class="container">
    <center><h4><b>Ballon Arch</b></h4> 
	<center><h4 style="color:darkblue;"><b>Decoration id: 3</b></h4>
    <p>€500</p> 
     
	
    
	
   
  </div>

</div>

<div class="card"  position:relative>
  <img src="surprize.jpg" alt="Avatar" style="width:100%">
  <div class="container">
    
    <center><h4><b>Surprize Decoration Package</b></h4>
<center><h4 style="color:darkblue;"><b>Decoration id: 4</b></h4>	
    <p>€800</p> 
	
  </div>
</div>


</div>



<style>
 .card {
    /* Add shadows to create the "card" effect */
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
    background-color:;
    width: 0px;
    height: 500px;
    
}

/* On mouse-over, add a deeper shadow */
.card:hover {
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {
    padding: 2px 16px;

    }

    button {
    background-color: #B0C4DE;
    color: white;
    padding: 5px 50px;
    /*margin: 8px 0px;*/

    border: 0.5px;
    cursor: pointer;
    width: 100%;
}

    button:hover {
    opacity: 1;

}
div{
display: -webkit-flex; /* Safari */
-webkit-align-items: left;/* Safari 7.0+ */
-webkit-flex-wrap:wrap;
-webkit-justify-content:space-around;
    
}


    </style>


</BODY>
</HTML>

<?php include('footer.php'); ?>