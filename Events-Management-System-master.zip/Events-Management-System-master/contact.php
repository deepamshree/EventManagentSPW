<?php include('header.php'); ?>
<html>
<body>


 <div class="container">
   <br />
   
  <style>
ul {
    list-style-type: none;
    margin: 25;
    padding: 0;
    overflow: hidden;
    background-color:#B0C4DE;
    text-align: right;
}

li {
    float: left;
}

li a {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: underline;
}
li a:hover:not(.active) {
    background-color: white;
}




</style >
<p>
        <h1 style=color:#B0C4DE; >   PartyPies  </h1>
<h2 style=color:#B0C4DE;>   We plan for you </h2>
<h3 style=color:#B0C4DE;>  An exclusive Project for the purpose of SPW Project</h3>
		<h2 style="color:#B0C4DE; font-size: 150%;">Deepashree Chandrashekar<br>Ajay Karthi Punetha Velu<br>Meghana Naveen<br>Praveenraj Raveendran<br><br></h2>
		</p>

  
 



</body>
</html>