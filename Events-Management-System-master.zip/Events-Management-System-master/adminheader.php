<!DOCTYPE html>
<html>
<head>

	<title>partypies event registration</title>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body style="background-image: url(logo2.jpg);">
<nav class="navbar navbar-expand-lg  navbar-light bg-light">
  <a class="navbar-brand" href="index.php">
    <img src="logo.png" width="40%" height="40%" class="d-inline-block align-top" alt="klu">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" style="font-size: 130%;">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact us <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="about.php">About us<span class="sr-only">(current)</span></a>
      </li>
	  <li class="nav-item active">
        <a class="nav-link" href="decorationtype.php">Decoration Packages<span class="sr-only">(current)</span></a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="edit.php">Edit <span class="sr-only">(current)</span></a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="delete.php">Delete <span class="sr-only">(current)</span></a>
      </li>
       
      <li class="nav-item active">
        <a class="nav-link" href="report.php">Report <span class="sr-only">(current)</span></a>
      </li>
      <!-- <li class="nav-item active">
        <a class="nav-link" href="login.php">Sign in/Sign up <span class="sr-only">(current)</span></a>
        
      </li> -->
    </ul>
		   <style>
ul {
    list-style-type: none;
    margin: 25;
    padding: 0;
    overflow: hidden;
    background-color:#B0C4DE;
    text-align: right;
}

li {
    float: left;
}

li a {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: underline;
}
li a:hover:not(.active) {
    background-color: white;
}




</style >
  </div>
</nav>