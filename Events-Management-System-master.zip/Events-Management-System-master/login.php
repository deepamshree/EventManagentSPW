<!doctype html>
<html>
<?php include('header.php'); ?>
<?php  include("dbconnect.php"); ?>
<center>
<h3 style="padding: 10px;color:Black; background-color:#B0C4DE">Birthday Event Registration:</h3>
<div class="jumbotron col-6" style=" font-weight: bold;">
<form  action='config.php' method='post'>
     <body>

        <div class="col-md-7">
          <div class="panel panel-default">
           <div class="panel-heading">
                 <h4 class="panel-title"><strong>Login Here!!!!</strong></h4>
            </div>

           <div class="panel-body">
            <form method="post" action="config.php">

               <div class="form-group">
                <label for="username">User Name</label>
                <input type="text" class="form-control" name="name" id="username" placeholder="Enter Name">
              </div>

              <div class="form-group">
                 <label for="userpass">Password</label>
                 <input type="password" class="form-control" name="password" id="userpass" placeholder="Enter Password">
              </div>

              <button type="submit" class="btn btn-default" name="btn-login" name="btn-login">Submit</button>
              
              </form>

  </div> 
  </div>
    
  
   </body>
   </html>