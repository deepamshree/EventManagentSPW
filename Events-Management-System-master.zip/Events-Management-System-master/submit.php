
<?php 

include("dbconnect.php"); 

 

$name = mysqli_real_escape_string($db_connect, $_REQUEST['name']); 

$email = mysqli_real_escape_string($db_connect, $_REQUEST['email']); 

$phone = mysqli_real_escape_string($db_connect, $_REQUEST['phone']); 

$gender = mysqli_real_escape_string($db_connect, $_REQUEST['gender']); 

 

$query = mysqli_prepare($db_connect, "INSERT INTO customer(name, email, phone, gender) VALUES (?, ?, ?, ?)"); 

mysqli_stmt_bind_param($query, 'ssss', $name, $email, $phone, $gender); 

if(mysqli_stmt_execute($query)) { 

    echo "<script type='text/javascript'>alert('Succesfully Submitted! '); 

        window.location = 'index.php'; 
    
    </script>"; 
    header('location: event.php');
} else { 

    echo "<script type='text/javascript'>alert('Error in Submission! Try Again '); 

        window.location = 'index.php'; 

    </script>"; 
   
} 
header('location: event.php');
 

mysqli_stmt_close($query); 

mysqli_close($db_connect); 

 ?> 