<?php include('header.php'); ?>
<html>
<body>


 <div class="container">
   <br />
   
  <style>
ul {
    list-style-type: none;
    margin: 25;
    padding: 0;
    overflow: hidden;
    background-color:#B0C4DE;
    text-align: right;
}

li {
    float: left;
}

li a {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: underline;
}
li a:hover:not(.active) {
    background-color: white;
}




</style >

        <h1 style=color:#B0C4DE; >  OUR VISION </h1>
		
<p style="color:#B0C4DE;font-size: 150%;">There are a lot of event companies that do what we do.<br> They “Definitely” share the same "What" and "How".<br> What makes us really different is our “Why”. 

We create<br> “Experiences” not just “Events”. We love crafting every project <br>with a true passion & attention to detail and we value relationships <br>above all else..<br>

We are focused on turning dreams to reality. <br>Innovating, pushing boundaries, and insisting on nothing but perfection<br> from ourselves. Our wide-range of expertise has allowed us to create <br>parties for all types of birthdays.<br> 
So, let's party!</p>


  
 



</body>
</html>