<?php 

 

function fetch_data() { 

    $output = ''; 

    $conn = mysqli_connect("localhost", "root", "", "project"); 

    $sql = "SELECT * FROM customer ORDER BY eventid"; 

    $result = mysqli_query($conn, $sql); 

    while($row = mysqli_fetch_array($result)) { 

        $output .= '<tr>   

                <td style="background-color:#fff;">'.htmlspecialchars($row["eventid"]).'</td>   

                <td style="background-color:#fff;">'.htmlspecialchars($row["name"]).'</td>   

                <td style="background-color:#fff;">'.htmlspecialchars($row["email"]).'</td>   

                <td style="background-color:#fff;">'.htmlspecialchars($row["phone"]).'</td> 

                <td style="background-color:#fff;">'.htmlspecialchars($row["gender"]).'</td> 

            </tr>'; 

    } 

    return $output; 

} 

 

?> 

<?php include('header.php'); ?> 

<center> 

 

    <h3 style="padding: 10px;color:Black; background-color:#B0C4DE">Delete Registration entry:</h3> 

 

    <form action="dodelete.php" method="post" style="padding-bottom: 40px;"> 

        <div class="input-group col-6"> 

            <input type="int" name="eventid" class="form-control" placeholder="Enter id of the entry to be deleted" required> 

            <span class="input-group-btn"> 

                <button class="btn btn-secondary" type="submit" value="submit">Delete!</button> 

            </span> 

        </div> 

    </form> 

 

    <h3 style="padding: 20px;">Records In Database:</h3> 

 

    <div class="table-responsive table-hover table-bordered col-10"> 

        <table class="table"> 

            <thead>  

                <tr class="table-primary"> 

                    <th width="1%">eventId</th> 

                    <th width="1%">Name</th> 

                    <th width="1%">Email</th> 

                    <th width="1%">Phone</th> 

                    <th width="1%">Gender</th> 

                </tr> 

            </thead> 

            <tbody> 

                <?php 

                echo fetch_data(); 

                ?> 

            </tbody> 

        </table> 

    </div> 

</center> 

 

<?php include('footer.php'); ?> 